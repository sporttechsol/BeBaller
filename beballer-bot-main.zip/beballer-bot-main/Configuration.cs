﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beballer_bot
{
    class Configuration
    {
        public readonly static string BotToken = "{Token}";

        public readonly static string ConnectDB = "{Connect}";
    }
}
