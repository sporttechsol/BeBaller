﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot.Types;

namespace beballer_bot
{
    class SqlServices
    {
        public static async void AddGroup(long ChatId, string Title)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
                {
                    connection.Open();
                    String sql = $"INSERT INTO [dbo].[groups] ([group_id],[title]) VALUES (@param1, @param2)";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.Add("@param1", SqlDbType.NVarChar).Value = ChatId;
                        command.Parameters.Add("@param2", SqlDbType.NVarChar).Value = Title;

                        command.CommandType = CommandType.Text;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            { }
        }

        public static async void AddAdminGroup(long ChatId, long UserId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
                {
                    connection.Open();
                    String sql = $"INSERT INTO [dbo].[group_admins] ([group_id],[user_id]) VALUES (@param1, @param2)";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.Add("@param1", SqlDbType.NVarChar).Value = ChatId;
                        command.Parameters.Add("@param2", SqlDbType.NVarChar).Value = UserId;

                        command.CommandType = CommandType.Text;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            { }
        }

        public static bool CheckAdminGroup(long ChatId, long UserId)
        {
            using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
            {
                connection.Open();
                String sql = $"SELECT COUNT(*) as CNT FROM [dbo].[group_admins] Where [group_id] = '{ChatId}' and [user_id] = '{UserId}'";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    int cnt = (int)command.ExecuteScalar();
                    return Convert.ToBoolean(cnt);
                }
            }
        }

        public static string GetGroupId(long UserId)
        {
            using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
            {
                connection.Open();
                String sql = $"SELECT [group_id] FROM [dbo].[group_admins] Where [user_id] = '{UserId}'";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    var group = command.ExecuteReader();
                    string list = "";

                    while (group.Read())
                    {
                        list = group["group_id"].ToString();

                    }                   
                    return list;
                }
            }
        }

        public static void AddEvent(string GroupId, string[] param_event, int msgId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
                {
                    connection.Open();
                    String sql = $"INSERT INTO [dbo].[events] ([group_id],[title],[date],[players_needed],[comment],[start_time],[end_time],[status], [msg_id]) VALUES (@param1, @param2, @param3, @param4, @param5, @param6, @param7, @param8, @param9)";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.Add("@param1", SqlDbType.NVarChar).Value = GroupId;
                        command.Parameters.Add("@param2", SqlDbType.Text).Value = param_event[0];
                        command.Parameters.Add("@param3", SqlDbType.Date).Value = DateTime.Now;
                        command.Parameters.Add("@param4", SqlDbType.Int).Value =  Convert.ToInt64(param_event[4]);
                        command.Parameters.Add("@param5", SqlDbType.Text).Value = param_event[5];
                        command.Parameters.Add("@param6", SqlDbType.NVarChar).Value = param_event[2];
                        command.Parameters.Add("@param7", SqlDbType.NVarChar).Value = param_event[3];
                        command.Parameters.Add("@param8", SqlDbType.Int).Value = 1;
                        command.Parameters.Add("@param9", SqlDbType.Int).Value = msgId;

                        command.CommandType = CommandType.Text;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            { }
        }

        //public static bool CreateOrUpdateVote()
        //{
        //    //try
        //    //{
        //    //    using (SqlConnection connection = new SqlConnection(Configuration.ConnectDB))
        //    //    {
        //    //        connection.Open();
        //    //        String sql = $"SELECT COUNT(*) as CNT FROM [dbo].[group_admins] Where [group_id] = '{ChatId}' and [user_id] = '{UserId}'";

        //    //        using (SqlCommand command = new SqlCommand(sql, connection))
        //    //        {
        //    //            int cnt = (int)command.ExecuteScalar();
        //    //            return Convert.ToBoolean(cnt);
        //    //        }
        //    //    }
        //    //}
        //    //catch(Exception ex) {
        //    //    return false;
        //    //}
        //}
    }
}
