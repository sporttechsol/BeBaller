package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	_ "github.com/denisenkom/go-mssqldb"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

type InputEvent = map[string]interface{}

type OutputEvent struct {
	Name string                 `json:"name"`
	Data map[string]interface{} `json:"data"`
}

type InputEventProcessor interface {
	ProcessEvent(event *OutputEvent, input InputEvent)
}

type InputEventProcessorFunc func(event *OutputEvent, input InputEvent)

func (f InputEventProcessorFunc) ProcessEvent(event *OutputEvent, input InputEvent) {
	f(event, input)
}

type Subscribers struct {
	sync.Mutex
	list []chan *OutputEvent
}

func (s *Subscribers) Add(sub chan *OutputEvent) {
	s.Lock()
	defer s.Unlock()
	s.list = append(s.list, sub)
}

func (s *Subscribers) Remove(sub chan *OutputEvent) {
	s.Lock()
	defer s.Unlock()

	var index = 0

	for i, c := range s.list {
		if sub == c {
			index = i
		}
	}

	s.list = append(s.list[:index], s.list[index+1:]...)
}

func (s *Subscribers) Publish(event *OutputEvent) {
	s.Lock()
	defer s.Unlock()

	for _, sub := range s.list {
		sub <- event
	}
}

func (s *Subscribers) Handler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := upgrader.Upgrade(w, r, nil)

		if err != nil {
			log.Printf("Connection upgrade error: %err\n", err)
			return
		}

		defer c.Close()

		eventStream := make(chan *OutputEvent, 5)

		s.Add(eventStream)

		log.Printf("New client \"%s\" connected\n", c.RemoteAddr().String())

		for event := range eventStream {
			if err := c.WriteJSON(event); err != nil {
				log.Printf("Failed to send message to client: %s\n", err)
				break
			}
		}

		s.Remove(eventStream)
	}
}

type Hub struct {
	Subscribers
	EventProcessor InputEventProcessor
}

func (h *Hub) PublishHandler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if "POST" != r.Method {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		defer r.Body.Close()

		var inputEvent InputEvent

		if err := json.NewDecoder(r.Body).Decode(&inputEvent); err != nil {
			log.Printf("Failed to decode an input event: %s\n", err)
			w.WriteHeader(http.StatusBadRequest)
			return
		}

		log.Printf("Got event from master service\n")

		event := OutputEvent{}

		if h.EventProcessor == nil {
			h.EventProcessor.ProcessEvent(&event, inputEvent)
		}

		h.Publish(&event)

		w.WriteHeader(http.StatusAccepted)
	}
}

func (h *Hub) Monitor() {
	go func() {
		event := OutputEvent{}
		event.Name = "ping"

		for range time.Tick(3 * time.Second) {
			h.Publish(&event)
		}
	}()
}

type beBallerEventProcessor struct {
}

func (p *beBallerEventProcessor) ProcessEvent(event *OutputEvent, input InputEvent) {

}

type Participant struct {
	EventId int     `json:"event_id"`
	Player  *Player `json:"player"`
	Status  int     `json:"status"`
	IsMain  bool    `json:"is_main"`
}

func GetParticipants(db *sql.DB, eventId int) ([]Participant, error) {
	var participants []Participant

	var rows *sql.Rows
	var err error

	rows, err = db.Query("SELECT event_id, user_id, status, is_main FROM event_players WHERE event_id = @p1", eventId)

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	var playersCache map[string]*Player

	for rows.Next() {
		participant := Participant{}

		var userId string

		if err := rows.Scan(&participant.EventId, &userId, &participant.Status, &participant.IsMain); err != nil {
			return nil, err
		}

		player, ok := playersCache[userId]

		if !ok {
			players, _ := GetPlayers(db, userId)

			if len(players) != 0 {
				player = &players[0]
			}
		}

		participant.Player = player

		participants = append(participants, participant)
	}

	return participants[:], nil
}

type PlayerEventSummary struct {
	UserId  string    `json:"user_id"`
	EventId string    `json:"event_id"`
	Result  int       `json:"result"`
	Stamp   time.Time `json:"stamp"`
}

func GetPlayersEventSummary(db *sql.DB, eventId int) ([]PlayerEventSummary, error) {
	var eventSummary []PlayerEventSummary

	rows, err := db.Query("SELECT user_id, event_id, result, date FROM player_event_summary WHERE event_id = @p1", eventId)

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	for rows.Next() {
		playerSummary := PlayerEventSummary{}

		if err := rows.Scan(&playerSummary.UserId, &playerSummary.EventId, &playerSummary.Result, &playerSummary.Stamp); err != nil {
			return nil, err
		}

		eventSummary = append(eventSummary, playerSummary)
	}

	return eventSummary[:], err
}

type Event struct {
	Id             int                  `json:"id"`
	GroupId        string               `json:"group_id"`
	Title          string               `json:"title"`
	StartDate      time.Time            `json:"start_date"`
	EndDate        time.Time            `json:"end_date"`
	PlayersNeeded  int                  `json:"players_needed"`
	Comment        string               `json:"comment"`
	Status         int                  `json:"status"`
	Participants   []Participant        `json:"participants"`
	PlayersSummary []PlayerEventSummary `json:"summary"`
}

func GetEvents(db *sql.DB, groupId string) ([]Event, error) {
	var events []Event

	var rows *sql.Rows
	var err error

	if "" == groupId {
		rows, err = db.Query("SELECT event_id, group_id, title, date, players_needed, comment, start_time, end_time, status FROM events")
	} else {
		rows, err = db.Query("SELECT event_id, group_id, title, date, players_needed, comment, start_time, end_time, status FROM events WHERE group_id = @p1", groupId)
	}

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	for rows.Next() {
		event := Event{}

		var eventDate time.Time
		var startTime string
		var endTime string

		if err := rows.Scan(&event.Id, &event.GroupId, &event.Title, &eventDate, &event.PlayersNeeded, &event.Comment, &startTime, &endTime, &event.Status); err != nil {
			return nil, err
		}

		startTimeHM := strings.Split(startTime, ":")
		startTimeH, _ := strconv.Atoi(startTimeHM[0])
		startTimeM, _ := strconv.Atoi(startTimeHM[1])

		event.StartDate = time.Date(eventDate.Year(), eventDate.Month(), eventDate.Day(), startTimeH, startTimeM, 0, 0, eventDate.Location())

		endTimeHM := strings.Split(endTime, ":")
		endTimeH, _ := strconv.Atoi(endTimeHM[0])
		endTimeM, _ := strconv.Atoi(endTimeHM[1])

		event.EndDate = time.Date(eventDate.Year(), eventDate.Month(), eventDate.Day(), endTimeH, endTimeM, 0, 0, eventDate.Location())

		event.Participants, _ = GetParticipants(db, event.Id)
		event.PlayersSummary, _ = GetPlayersEventSummary(db, event.Id)

		events = append(events, event)
	}

	return events[:], nil
}

type Group struct {
	Id          string  `json:"id"`
	Title       string  `json:"title"`
	PlayerCount int     `json:"player_count"`
	Events      []Event `json:"events"`
}

func GetGroups(db *sql.DB, groupId string) ([]Group, error) {
	var groups []Group

	var rows *sql.Rows
	var err error

	if "" == groupId {
		rows, err = db.Query("SELECT group_id, title, players_count FROM groups")
	} else {
		rows, err = db.Query("SELECT group_id, title, players_count FROM groups WHERE group_id = @p1", groupId)
	}

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	for rows.Next() {
		group := Group{}

		if err := rows.Scan(&group.Id, &group.Title, &group.PlayerCount); err != nil {
			return nil, err
		}

		group.Events, _ = GetEvents(db, group.Id)

		groups = append(groups, group)
	}

	return groups[:], nil
}

type Player struct {
	Id          string `json:"id"`
	Status      int    `json:"status"`
	DisplayName string `json:"display_name"`
	WinRate     int    `json:"win_rate"`
	Karma       int    `json:"karma"`
}

func GetPlayers(db *sql.DB, playerId string) ([]Player, error) {
	var players []Player

	var rows *sql.Rows
	var err error

	if "" == playerId {
		rows, err = db.Query("SELECT user_id, status, display_name, karma, win_rating FROM players")
	} else {
		rows, err = db.Query("SELECT user_id, status, display_name, karma, win_rating FROM players WHERE user_id = @p1", playerId)
	}

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	for rows.Next() {
		player := Player{}

		if err := rows.Scan(&player.Id, &player.Status, &player.DisplayName, &player.Karma, &player.WinRate); err != nil {
			return nil, err
		}

		players = append(players, player)
	}

	return players[:], nil
}

func main() {
	connString := fmt.Sprintf("server=%s;user id=%s;password=%s;port=%d;database=%s;",
		"timeter.database.windows.net",
		"sysdba",
		"theT1meter!",
		1433,
		"beballer_hackaton",
	)

	db, err := sql.Open("sqlserver", connString)

	if err != nil {
		log.Fatalf("Failed to connect database: %s", err)
	}

	if err := db.Ping(); err != nil {
		log.Fatalf("Failed to ping database: %v", err)
	}

	r := gin.Default()

	hub := Hub{}

	hub.EventProcessor = InputEventProcessorFunc(func(event *OutputEvent, input InputEvent) {
		// Do handle input events
	})

	// Run hub monitoring
	hub.Monitor()

	subHandler := hub.Handler()
	pubHandler := hub.PublishHandler()

	r.GET("/notify", func(c *gin.Context) {
		subHandler(c.Writer, c.Request)
	})

	r.GET("/events", func(c *gin.Context) {
		events, err := GetEvents(db, "")

		if err != nil {
			c.String(http.StatusInternalServerError, "")
			return
		}

		c.JSON(http.StatusOK, events)
	})

	r.POST("/events", func(c *gin.Context) {
		pubHandler(c.Writer, c.Request)
	})

	r.GET("/groups", func(c *gin.Context) {
		groups, err := GetGroups(db, "")

		if err != nil {
			c.String(http.StatusInternalServerError, "")
			return
		}

		c.JSON(http.StatusOK, groups)
	})

	r.GET("/groups/:group_id", func(c *gin.Context) {
		groups, err := GetGroups(db, c.GetString("group_id"))

		if err != nil {
			c.String(http.StatusInternalServerError, "")
			return
		}

		if len(groups) == 0 {
			c.String(http.StatusNotFound, "")
			return
		}

		c.JSON(http.StatusOK, groups[0])
	})

	r.GET("/players", func(c *gin.Context) {
		players, err := GetPlayers(db, "")

		if err != nil {
			c.String(http.StatusInternalServerError, "")
			return
		}

		c.JSON(http.StatusOK, players)
	})

	r.GET("/events/:event_id/players", func(c *gin.Context) {

	})

	r.Run(":8080")
}
